/* ════════════════════════════════════════════════
   vibewithflow — app.js
   Interactive layer: arc nav, CD player,
   likes, cursor glow, glitch effects
   ════════════════════════════════════════════════ */

'use strict';

/* ── DATA ─────────────────────────────────────── */
const VIBES = [
  'Indie Hits', 'Women Who Rock', 'Award Season',
  'Beach Buzz', 'Late Night', 'Golden Era',
  'Underground', 'New Wave', 'Chill Mode',
  'Road Trip', 'Dark Hours', 'Feel Good'
];

const TRACKS = [
  { title: 'Neon Dreams',      artist: 'The Signal',        color: '#ff3cac', bg: '#1a0028' },
  { title: 'Glitch Heart',     artist: 'Vex & Flow',        color: '#ff69b4', bg: '#200030' },
  { title: 'Static Love',      artist: 'Hollow Echo',       color: '#c77dff', bg: '#0d001a' },
  { title: 'Algorithm',        artist: 'MIRA',              color: '#ff3cac', bg: '#1f0020' },
  { title: 'Dark Frequencies', artist: 'Pulse Wraith',      color: '#00f5ff', bg: '#001a1f' },
  { title: 'Retrowave',        artist: 'Signal//Noise',     color: '#ff9de2', bg: '#1a0015' },
  { title: 'Cosmic Static',    artist: 'Dusk Patrol',       color: '#bd00ff', bg: '#0f0018' },
  { title: 'Pink Overload',    artist: 'Vera Lynn Clone',   color: '#ff3cac', bg: '#1a0012' },
  { title: 'Synthetic Soul',   artist: 'Circuit Bloom',     color: '#ff69b4', bg: '#1a0025' },
];

const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

/* ── STATE ────────────────────────────────────── */
let currentSection  = 'home';
let activeVibe      = 0;          // index into VIBES
let activeCDIndex   = 4;          // centre of carousel (0-based of TRACKS)
let likedTracks     = new Set();
let isPlaying       = true;
let arcVibes        = [];          // stores arc item metadata for hit-testing

/* ── DOM REFS ─────────────────────────────────── */
const heroSection    = document.getElementById('hero');
const vibeSection    = document.getElementById('vibe-section');
const letterSection  = document.getElementById('letter-section');
const playerSection  = document.getElementById('player-section');
const aboutSection   = document.getElementById('about');

const arcCanvas      = document.getElementById('arc-canvas');
const arcCtx         = arcCanvas ? arcCanvas.getContext('2d') : null;
const centerVibeName = document.getElementById('center-vibe-name');
const playVibeBtn    = document.getElementById('play-vibe-btn');
const surpriseBtn    = document.getElementById('surprise-btn');

const cdTrackList    = document.getElementById('cd-track-list');
const nowTrack       = document.getElementById('now-playing-track');
const nowArtist      = document.getElementById('now-playing-artist');
const pauseBtn       = document.getElementById('pause-btn');
const likeBtn        = document.getElementById('like-btn');
const likesList      = document.getElementById('likes-list');
const likesEmpty     = document.getElementById('likes-empty-msg');
const currentVibeLbl = document.getElementById('current-vibe-label');

const letterGrid     = document.getElementById('letter-grid');
const cursorGlow     = document.getElementById('cursor-glow');

/* ══════════════════════════════════════════════
   SECTION NAVIGATION
══════════════════════════════════════════════ */
function showSection(name) {
  // hide all
  [heroSection, vibeSection, letterSection, playerSection].forEach(s => {
    if (s) s.style.display = 'none';
  });

  currentSection = name;

  if (name === 'home') {
    heroSection.style.display = 'flex';
  } else if (name === 'vibe') {
    vibeSection.style.display  = 'flex';
    requestAnimationFrame(drawArc);
  } else if (name === 'letter') {
    letterSection.style.display = 'flex';
    buildLetterGrid();
  } else if (name === 'player') {
    playerSection.style.display = 'flex';
    buildCarousel();
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Expose globally for onclick
window.showSection = showSection;

/* ══════════════════════════════════════════════
   ARC VIBE SELECTOR
══════════════════════════════════════════════ */
function drawArc() {
  if (!arcCtx) return;

  const W = arcCanvas.width;
  const H = arcCanvas.height;
  arcCtx.clearRect(0, 0, W, H);

  arcVibes = [];

  // Arc parameters
  const cx    = W / 2;
  const cy    = H + 10;            // centre of arc circle is below canvas
  const R     = H * 1.52;          // radius of arc
  const totalVibes = VIBES.length;

  // Angular spread across the top of a half-circle
  const spreadRad = Math.PI * 0.68; // ~122° total
  const startAng  = Math.PI + (Math.PI - spreadRad) / 2; // left side
  const stepAng   = spreadRad / (totalVibes - 1);

  VIBES.forEach((vibe, i) => {
    const angle = startAng + i * stepAng;
    const x = cx + R * Math.cos(angle);
    const y = cy + R * Math.sin(angle);

    const isActive   = i === activeVibe;
    const distToActive = Math.abs(i - activeVibe);

    // === Draw separator ✦ between items ===
    if (i > 0) {
      const midAngle = startAng + (i - 0.5) * stepAng;
      const mx = cx + R * Math.cos(midAngle);
      const my = cy + R * Math.sin(midAngle);
      arcCtx.save();
      arcCtx.translate(mx, my);
      arcCtx.rotate(midAngle + Math.PI / 2);
      arcCtx.font = '10px Space Mono, monospace';
      arcCtx.fillStyle = 'rgba(255,60,172,0.45)';
      arcCtx.textAlign = 'center';
      arcCtx.textBaseline = 'middle';
      arcCtx.fillText('✦', 0, 0);
      arcCtx.restore();
    }

    // === Draw label ===
    arcCtx.save();
    arcCtx.translate(x, y);
    // Rotate text tangentially to arc
    arcCtx.rotate(angle + Math.PI / 2);

    const alpha  = Math.max(0.25, 1 - distToActive * 0.18);
    const size   = isActive ? 15 : Math.max(9, 13 - distToActive * 1.2);

    arcCtx.font = `${isActive ? 'bold ' : ''}${size}px 'Space Mono', monospace`;
    arcCtx.fillStyle = isActive
      ? '#ff3cac'
      : `rgba(${isActive ? '255,60,172' : '180,100,180'},${alpha})`;

    if (isActive) {
      arcCtx.shadowColor = '#ff3cac';
      arcCtx.shadowBlur  = 14;
    }

    arcCtx.textAlign    = 'center';
    arcCtx.textBaseline = 'middle';
    arcCtx.fillText(vibe, 0, 0);
    arcCtx.restore();

    // Store hit rect for click detection
    const textW = arcCtx.measureText(vibe).width + 20;
    arcVibes.push({ i, x, y, w: textW + 20, h: 26, angle });
  });
}

// Click on arc canvas
if (arcCanvas) {
  arcCanvas.addEventListener('click', e => {
    const rect = arcCanvas.getBoundingClientRect();
    const mx   = e.clientX - rect.left;
    const my   = e.clientY - rect.top;

    arcVibes.forEach(item => {
      const dx = mx - item.x;
      const dy = my - item.y;
      if (Math.sqrt(dx * dx + dy * dy) < 50) {
        activeVibe = item.i;
        updateVibeCenter();
        drawArc();
      }
    });
  });

  arcCanvas.addEventListener('mousemove', e => {
    const rect = arcCanvas.getBoundingClientRect();
    const mx   = e.clientX - rect.left;
    const my   = e.clientY - rect.top;

    let hovering = false;
    arcVibes.forEach(item => {
      const dx = mx - item.x;
      const dy = my - item.y;
      if (Math.sqrt(dx * dx + dy * dy) < 50) hovering = true;
    });
    arcCanvas.style.cursor = hovering ? 'none' : 'default';
  });
}

function updateVibeCenter() {
  const name = VIBES[activeVibe];
  if (centerVibeName) centerVibeName.textContent = name;
  if (playVibeBtn)    playVibeBtn.textContent     = `PLAY ${name.toUpperCase()}`;
  if (currentVibeLbl) currentVibeLbl.textContent  = name.toUpperCase();
}

// Play vibe  → go to player
if (playVibeBtn) {
  playVibeBtn.addEventListener('click', () => showSection('player'));
}

// Surprise me
if (surpriseBtn) {
  surpriseBtn.addEventListener('click', () => {
    activeVibe = Math.floor(Math.random() * VIBES.length);
    updateVibeCenter();
    drawArc();
    setTimeout(() => showSection('player'), 500);
  });
}

/* ══════════════════════════════════════════════
   LETTER GRID
══════════════════════════════════════════════ */
function buildLetterGrid() {
  if (!letterGrid) return;
  letterGrid.innerHTML = '';

  LETTERS.forEach(letter => {
    const btn = document.createElement('button');
    btn.className  = 'letter-btn';
    btn.innerHTML  = `<span>${letter}</span>`;
    btn.title      = `Artists starting with ${letter}`;
    btn.id         = `letter-btn-${letter}`;
    btn.addEventListener('click', () => {
      // Filter tracks by letter and go to player
      activeCDIndex = 0;
      showSection('player');
    });
    letterGrid.appendChild(btn);
  });
}

/* ══════════════════════════════════════════════
   CD CAROUSEL / PLAYER
══════════════════════════════════════════════ */
function buildCarousel() {
  if (!cdTrackList) return;
  cdTrackList.innerHTML = '';

  TRACKS.forEach((track, i) => {
    const disc = document.createElement('div');
    disc.className = `cd-disc${i === activeCDIndex ? ' active' : ''}`;
    disc.id        = `disc-${i}`;

    // Coloured disc background
    disc.style.background = `radial-gradient(circle at 30% 30%, ${track.color}55, ${track.bg} 70%)`;
    disc.style.boxShadow  = i === activeCDIndex
      ? `0 0 60px ${track.color}88, 0 20px 60px rgba(0,0,0,0.8)`
      : `0 8px 30px rgba(0,0,0,0.7)`;

    // Build inner elements
    disc.innerHTML = `
      <div class="disc-img-wrapper">
        ${buildDiscRings(i)}
        <div class="disc-label">${track.title}</div>
        <div class="disc-center-hole"></div>
      </div>`;

    disc.addEventListener('click', () => {
      activeCDIndex = i;
      refreshCarousel();
    });

    cdTrackList.appendChild(disc);
  });

  refreshNowPlaying();
  positionCarousel();
}

function buildDiscRings(idx) {
  const track = TRACKS[idx];
  const rings  = [40, 60, 75, 88].map(pct => `
    <div class="disc-ring" style="
      width:${pct}%; height:${pct}%;
      border-color: ${track.color}${Math.round(0.15 * 255).toString(16).padStart(2,'0')};
    "></div>`).join('');
  return rings;
}

function refreshCarousel() {
  const discs = cdTrackList.querySelectorAll('.cd-disc');
  discs.forEach((disc, i) => {
    disc.classList.toggle('active', i === activeCDIndex);
    const track = TRACKS[i];
    disc.style.background = `radial-gradient(circle at 30% 30%, ${track.color}55, ${track.bg} 70%)`;
    disc.style.boxShadow  = i === activeCDIndex
      ? `0 0 60px ${track.color}88, 0 20px 60px rgba(0,0,0,0.8)`
      : `0 8px 30px rgba(0,0,0,0.7)`;
  });
  refreshNowPlaying();
  positionCarousel();
}

function positionCarousel() {
  if (!cdTrackList) return;
  const discW = 240; // active disc width
  const gap   = -20;
  const offset = -activeCDIndex * (200 + gap) + (cdTrackList.parentElement.offsetWidth / 2 - discW / 2);
  cdTrackList.style.transform = `translateX(${offset}px)`;
}

function refreshNowPlaying() {
  const t = TRACKS[activeCDIndex];
  if (nowTrack)  nowTrack.textContent  = t.title;
  if (nowArtist) nowArtist.textContent = t.artist;
  // update like button state
  if (likeBtn) {
    likeBtn.classList.toggle('liked', likedTracks.has(activeCDIndex));
  }
}

function shiftCD(dir) {
  activeCDIndex = (activeCDIndex + dir + TRACKS.length) % TRACKS.length;
  refreshCarousel();
}
window.shiftCD = shiftCD;

/* ── Pause/Play ── */
if (pauseBtn) {
  pauseBtn.addEventListener('click', () => {
    isPlaying = !isPlaying;
    pauseBtn.textContent = isPlaying ? '⏸' : '▶';
    const activeDisc = document.querySelector('.cd-disc.active .disc-img-wrapper');
    if (activeDisc) {
      activeDisc.style.animationPlayState = isPlaying ? 'running' : 'paused';
    }
  });
}

/* ── Like ── */
if (likeBtn) {
  likeBtn.addEventListener('click', () => {
    if (likedTracks.has(activeCDIndex)) {
      likedTracks.delete(activeCDIndex);
      likeBtn.classList.remove('liked');
    } else {
      likedTracks.add(activeCDIndex);
      likeBtn.classList.add('liked');
      // Animate
      likeBtn.style.transform = 'scale(1.4)';
      setTimeout(() => likeBtn.style.transform = '', 300);
    }
    renderLikes();
  });
}

function renderLikes() {
  if (!likesList || !likesEmpty) return;
  likesList.innerHTML = '';
  if (likedTracks.size === 0) {
    likesEmpty.style.display = 'block';
  } else {
    likesEmpty.style.display = 'none';
    likedTracks.forEach(idx => {
      const li  = document.createElement('li');
      li.textContent = `${TRACKS[idx].title} — ${TRACKS[idx].artist}`;
      likesList.appendChild(li);
    });
  }
}

/* ── Keyboard navigation ── */
document.addEventListener('keydown', e => {
  if (currentSection === 'player') {
    if (e.key === 'ArrowRight') shiftCD(1);
    if (e.key === 'ArrowLeft')  shiftCD(-1);
    if (e.key === ' ')          pauseBtn && pauseBtn.click();
    if (e.key === 'l' || e.key === 'L') likeBtn && likeBtn.click();
    e.preventDefault && e.key === ' ' && e.preventDefault();
  }
  if (e.key === 'Escape') showSection('home');
});

/* ══════════════════════════════════════════════
   CURSOR GLOW
══════════════════════════════════════════════ */
if (cursorGlow) {
  let mx = -100, my = -100;
  let cx2 = -100, cy2 = -100;

  document.addEventListener('mousemove', e => {
    mx = e.clientX;
    my = e.clientY;
  });

  function animateCursor() {
    // Smooth lag
    cx2 += (mx - cx2) * 0.18;
    cy2 += (my - cy2) * 0.18;
    cursorGlow.style.left = cx2 + 'px';
    cursorGlow.style.top  = cy2 + 'px';
    requestAnimationFrame(animateCursor);
  }
  animateCursor();

  // Grow on hover interactive elements
  const interactives = 'a, button, .cd-card, .cd-disc, .letter-btn, [onclick]';
  document.querySelectorAll(interactives).forEach(el => {
    el.addEventListener('mouseenter', () => {
      cursorGlow.style.transform = 'translate(-50%,-50%) scale(2.5)';
      cursorGlow.style.opacity   = '0.6';
    });
    el.addEventListener('mouseleave', () => {
      cursorGlow.style.transform = 'translate(-50%,-50%) scale(1)';
      cursorGlow.style.opacity   = '1';
    });
  });
}

/* ══════════════════════════════════════════════
   RANDOM STATIC GLITCH FLASH
══════════════════════════════════════════════ */
function triggerGlitchFlash() {
  const glitchEl = document.querySelector('.italic-glitch, .logo-glitch');
  if (!glitchEl) return;
  glitchEl.style.transform = `translate(${rand(-4,4)}px, ${rand(-2,2)}px)`;
  setTimeout(() => { glitchEl.style.transform = ''; }, 80);
}

function rand(min, max) {
  return Math.random() * (max - min) + min;
}

setInterval(() => {
  if (Math.random() < 0.3) triggerGlitchFlash();
}, 2800);

/* ══════════════════════════════════════════════
   BIG LOGO HERO GLITCH ANIMATION
══════════════════════════════════════════════ */
(function bigLogoHero() {
  const logo = document.querySelector('.logo-glitch');
  if (!logo) return;

  setInterval(() => {
    // Random horizontal slice distortion
    const sliceCount = Math.floor(rand(3, 8));
    logo.style.filter = `hue-rotate(${rand(-30,30)}deg)`;
    logo.style.transform = `translate(${rand(-3,3)}px, 0)`;
    setTimeout(() => {
      logo.style.filter    = '';
      logo.style.transform = '';
    }, 100 + rand(0, 80));
  }, 3500 + rand(0, 2000));
})();

/* ══════════════════════════════════════════════
   SCANLINES OVERLAY (dynamic canvas)
══════════════════════════════════════════════ */
(function addScanlines() {
  const canvas = document.createElement('canvas');
  canvas.style.cssText = `
    position: fixed;
    inset: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 8999;
    opacity: 0.04;
    mix-blend-mode: overlay;
  `;
  document.body.appendChild(canvas);

  function resize() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
    drawScanlines();
  }

  function drawScanlines() {
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#fff';
    for (let y = 0; y < canvas.height; y += 3) {
      ctx.fillRect(0, y, canvas.width, 1);
    }
  }

  window.addEventListener('resize', resize);
  resize();
})();

/* ══════════════════════════════════════════════
   STAR / PARTICLE BACKGROUND
══════════════════════════════════════════════ */
(function particleBg() {
  const canvas = document.createElement('canvas');
  canvas.style.cssText = `
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 0;
    opacity: 0.45;
  `;
  document.body.prepend(canvas);

  const ctx    = canvas.getContext('2d');
  let   W, H;
  const STARS  = 120;
  let   stars  = [];

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }

  function initStars() {
    stars = Array.from({ length: STARS }, () => ({
      x:    Math.random() * W,
      y:    Math.random() * H,
      r:    Math.random() * 1.2 + 0.3,
      vx:   (Math.random() - 0.5) * 0.12,
      vy:   (Math.random() - 0.5) * 0.12,
      hue:  Math.random() < 0.3 ? '#ff3cac' : '#ffffff',
      alpha: Math.random() * 0.6 + 0.2,
    }));
  }

  function drawStars() {
    ctx.clearRect(0, 0, W, H);
    stars.forEach(s => {
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fillStyle = s.hue;
      ctx.globalAlpha = s.alpha + Math.sin(Date.now() * 0.001 + s.x) * 0.15;
      ctx.fill();
      ctx.globalAlpha = 1;

      s.x += s.vx;
      s.y += s.vy;
      if (s.x < 0) s.x = W;
      if (s.x > W) s.x = 0;
      if (s.y < 0) s.y = H;
      if (s.y > H) s.y = 0;
    });
    requestAnimationFrame(drawStars);
  }

  window.addEventListener('resize', () => { resize(); initStars(); });
  resize();
  initStars();
  drawStars();
})();

/* ══════════════════════════════════════════════
   HERO BIG LOGO ON LOAD (typed glitch effect)
══════════════════════════════════════════════ */
(function heroTyped() {
  const h1 = document.querySelector('.hero-headline');
  if (!h1) return;
  h1.style.opacity = '0';
  h1.style.transform = 'translateY(30px)';
  h1.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
  setTimeout(() => {
    h1.style.opacity   = '1';
    h1.style.transform = 'translateY(0)';
  }, 300);
})();

/* ══════════════════════════════════════════════
   INIT
══════════════════════════════════════════════ */
(function init() {
  showSection('home');
  updateVibeCenter();
  renderLikes();

  // ── Card buttons ──────────────────────────────
  const cardLetter = document.getElementById('card-letter');
  const cardVibe   = document.getElementById('card-vibe');
  const backBtn    = document.getElementById('back-to-home-btn');

  if (cardLetter) cardLetter.addEventListener('click', () => showSection('letter'));
  if (cardVibe)   cardVibe.addEventListener('click',   () => showSection('vibe'));
  if (backBtn)    backBtn.addEventListener('click',    () => showSection('home'));

  // ── WHAT IS link in nav → about section ───────
  const whatIsLink = document.getElementById('what-is-link');
  if (whatIsLink) {
    whatIsLink.addEventListener('click', e => {
      e.preventDefault();
      // hide all sections, show about
      [heroSection, vibeSection, letterSection, playerSection].forEach(s => {
        if (s) s.style.display = 'none';
      });
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    });
  }

  // ── Handle resize ─────────────────────────────
  window.addEventListener('resize', () => {
    if (currentSection === 'player') positionCarousel();
    if (currentSection === 'vibe')   drawArc();
  });

  // ── Cursor scale on hover ─────────────────────
  document.addEventListener('mouseover', e => {
    const el = e.target.closest('a, button, .cd-card, .cd-disc, .letter-btn');
    if (el && cursorGlow) {
      cursorGlow.style.transform = 'translate(-50%,-50%) scale(2.2)';
      cursorGlow.style.opacity   = '0.55';
    }
  });
  document.addEventListener('mouseout', e => {
    const el = e.target.closest('a, button, .cd-card, .cd-disc, .letter-btn');
    if (el && cursorGlow) {
      cursorGlow.style.transform = 'translate(-50%,-50%) scale(1)';
      cursorGlow.style.opacity   = '1';
    }
  });
})();
